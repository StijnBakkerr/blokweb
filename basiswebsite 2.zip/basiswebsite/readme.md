# Procesverslag
**Auteur:** -jouw naam-

Markdown cheat cheet: [Hulp bij het schrijven van Markdown](https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet). Nb. de standaardstructuur en de spartaanse opmaak zijn helemaal prima. Het gaat om de inhoud van je procesverslag. Besteedt de tijd voor pracht en praal aan je website.



## Bronnenlijst
1. -bron 1-
2. -bron 2-
3. -...-



## Eindgesprek (week 7/8)

-dit ging goed & dit was lastig-

**Screenshot(s):**

-screenshot(s) van je eindresultaat-



## Voortgang 3 (week 6)

-same as voortgang 1-



## Voortgang 2 (week 5)

-same as voortgang 1-



## Voortgang 1 (week 3)

### Stand van zaken

-dit ging goed & dit was lastig-

**Screenshot(s):**

-screenshot(s) van hoe ver je bent-

### Agenda voor meeting

-samen met je groepje opstellen-

### Verslag van meeting

-na afloop snel uitkomsten vastleggen-



## Intake (week 1)

**Je startniveau:** -rode piste-

**Je focus:** -extra aandacht voor de surface laag-

**Je opdracht:** -https://www.formula1.com/en.html-

**Screenshot(s):**

![screenshot(s) die een goed beeld geven van de website die je gaat maken](images/formula 1 home.png) ![](images/Formula 1 standings.png)

**Breakdown-schets(en):**

![-voorlopige breakdownschets(en) van een of beide pagina's van de site die je gaat maken-](images/dummy-image.svg)
![Sectie 1](images/Formula1Secties-1.jpg "sectie 1")
![](images/Formula 1 Secties-2.jpg)
![](images/Formula 1 Secties-3.jpg)
![](images/Formula 1 Secties-4.jpg)
![](images/Formula 1 Secties-5.jpg)
![](images/Formula 1 Secties-6.jpg)
![](images/Formula 1 Secties-7.jpg)

![formula 1](images/Formula 1 Secties-1.jpg)
